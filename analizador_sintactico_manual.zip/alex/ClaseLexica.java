package alex;

public enum ClaseLexica {
 IDEN, ENT, REAL, PAP, PCIERRE, IGUAL, COMA, 
 MAS, MENOS, POR, DIV, EVALUA, DONDE, EOF
}
